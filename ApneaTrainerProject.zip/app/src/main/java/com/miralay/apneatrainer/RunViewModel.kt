package com.miralay.apneatrainer

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class RunViewModel(app: Application) : AndroidViewModel(app) {
    private val timer = SessionTimer(app)
    val timerState: StateFlow<TimerState> = timer.state
    var plan: Plan? = null
        private set

    fun start(p: Plan) {
        plan = p
        timer.start(p) {
            viewModelScope.launch {
                (getApplication<App>()).db.sessionDao().insert(
                    SessionEntity(
                        planName = p.name,
                        startedAt = System.currentTimeMillis(),
                        totalSeconds = timerState.value.totalSeconds,
                        rounds = p.rounds,
                        notes = p.notes
                    )
                )
            }
        }
    }

    fun toggle() {
        if (timerState.value.running) timer.pause() else plan?.let { timer.start(it) }
    }

    fun stop() { timer.stop() }
}

@Composable
fun PlanScreen(type: String, onStart: (Plan) -> Unit, onBack: () -> Unit, vm: RunViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val basePlan = remember(type) {
        when (type) {
            "co2" -> Plans.co2()
            "o2" -> Plans.o2()
            "dynamic" -> Plans.dynamic()
            "fimm" -> Plans.freeImmersion()
            "hunt" -> Plans.huntSim()
            else -> Plans.co2()
        }
    }
    var rounds by remember { mutableIntStateOf(basePlan.rounds) }

    Scaffold(topBar = { TopAppBar(title = { Text(basePlan.name) }, navigationIcon = { IconButton(onClick = onBack) { Text("←") } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(basePlan.notes)
            OutlinedCard { Column(Modifier.padding(12.dp)) {
                Text("Adımlar", fontWeight = FontWeight.Bold)
                basePlan.steps.forEachIndexed { i, s -> Text("${i+1}. ${s.label} – ${format(s.seconds)}") }
            } }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Turlar:")
                FilledTonalButton(onClick = { if (rounds > 1) rounds-- }) { Text("-") }
                Text(rounds.toString())
                FilledTonalButton(onClick = { rounds++ }) { Text("+") }
            }
            Button(onClick = {
                val p = basePlan.copy(rounds = rounds)
                vm.start(p)
                onStart(p)
            }) { Text("Başlat") }
        }
    }
}

@Composable
fun RunScreen(onDone: () -> Unit, vm: RunViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val state by vm.timerState.collectAsState()
    Scaffold(topBar = { TopAppBar(title = { Text(vm.plan?.name ?: "Çalışma") }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(state.step?.label ?: "Hazır mısın?", style = MaterialTheme.typography.headlineSmall)
            Text(format(state.remaining), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
            LinearProgressIndicator(progress = if (state.step == null || state.step!!.seconds == 0) 0f else 1f - (state.remaining.toFloat() / state.step!!.seconds.toFloat()), modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { vm.toggle() }) { Text(if (state.running) "Duraklat" else "Devam") }
                OutlinedButton(onClick = { vm.stop(); onDone() }) { Text("Bitir") }
            }
            Spacer(Modifier.weight(1f))
            Text("Adım ${state.currentIndex + 1}/${state.totalSteps} • Toplam: ${format(state.totalSeconds)}")
        }
    }
}
