package com.miralay.apneatrainer

import androidx.room.*
import kotlinx.serialization.Serializable

@Serializable
data class Step(
    val label: String,
    val seconds: Int,
    val color: Long = 0xFF1E88E5,
)

@Serializable
data class Plan(
    val name: String,
    val steps: List<Step>,
    val rounds: Int = 1,
    val notes: String = ""
)

@Entity(tableName = "sessions")
data class SessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val planName: String,
    val startedAt: Long,
    val totalSeconds: Int,
    val rounds: Int,
    val notes: String,
)

@Dao
interface SessionDao {
    @Insert suspend fun insert(e: SessionEntity): Long
    @Query("SELECT * FROM sessions ORDER BY startedAt DESC LIMIT 100")
    suspend fun recent(): List<SessionEntity>
    @Query("DELETE FROM sessions") suspend fun clear()
}

@Database(entities = [SessionEntity::class], version = 1)
abstract class AppDatabase : RoomDatabase() { abstract fun sessionDao(): SessionDao }

object Plans {
    fun co2(): Plan {
        val hold = 120
        val rests = listOf(120, 90, 75, 60, 45, 30, 15, 15)
        val steps = rests.flatMapIndexed { idx, r ->
            listOf(
                Step("Hazırlık #${idx+1}", 30, 0xFF8E24AA),
                Step("Tut: ${format(hold)}", hold, 0xFF1E88E5),
                Step("Dinlen: ${format(r)}", r, 0xFF43A047),
            )
        }
        return Plan("CO₂ Tablosu", steps)
    }
    fun o2(): Plan {
        val rest = 120
        val holds = listOf(90, 105, 120, 135, 150, 165, 180)
        val steps = holds.flatMapIndexed { idx, h ->
            listOf(
                Step("Hazırlık #${idx+1}", 30, 0xFF8E24AA),
                Step("Tut: ${format(h)}", h, 0xFF1E88E5),
                Step("Dinlen: ${format(rest)}", rest, 0xFF43A047),
            )
        }
        return Plan("O₂ Tablosu", steps)
    }
    fun dynamic(): Plan {
        val reps = 8
        val steps = (1..reps).flatMap { i ->
            listOf(
                Step("Yatay ${i}. set (25–30 m)", 35, 0xFF1565C0),
                Step("Dinlen", 90, 0xFF43A047),
            )
        }
        return Plan("Dinamik Yüzme", steps, notes = "Hep rahat tempo. Form bozulursa erken bırak.")
    }
    fun freeImmersion(): Plan {
        val reps = 6
        val steps = (1..reps).flatMap { i ->
            listOf(
                Step("İniş ${i}", 25, 0xFF1976D2),
                Step("Dip bekleme", 10, 0xFFF9A825),
                Step("Çıkış", 25, 0xFF1976D2),
                Step("Yüzey Dinlen", 60, 0xFF43A047),
            )
        }
        return Plan("Free Immersion (4–5 m)", steps)
    }
    fun huntSim(): Plan {
        val reps = 5
        val steps = (1..reps).flatMap { i ->
            listOf(
                Step("İniş ${i}", 15, 0xFF1976D2),
                Step("Dip bekleme", 25, 0xFFF9A825),
                Step("Çıkış", 15, 0xFF1976D2),
                Step("Yüzey Dinlen", 120, 0xFF43A047),
            )
        }
        return Plan("Av Simülasyonu (5–6 m)", steps, notes = "Form ve sakinlik odaklı.")
    }
}
fun format(total: Int): String = "%d:%02d".format(total / 60, total % 60)
