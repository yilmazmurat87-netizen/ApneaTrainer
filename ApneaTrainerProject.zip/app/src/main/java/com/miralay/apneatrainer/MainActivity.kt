package com.miralay.apneatrainer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppRoot() }
    }
}

@Composable
fun AppRoot() {
    val nav = rememberNavController()
    MaterialTheme(colorScheme = lightColorScheme()) {
        NavHost(navController = nav, startDestination = "home") {
            composable("home") { HomeScreen(onPlan = { nav.navigate("plan/$it") }, onHistory = { nav.navigate("history") }) }
            composable("plan/{type}") {
                PlanScreen(type = it.arguments?.getString("type") ?: "co2", onStart = { plan -> nav.navigate("run/${plan.name}") }, onBack = { nav.popBackStack() })
            }
            composable("run/{name}") { RunScreen(onDone = { nav.popBackStack("home", inclusive = false) }) }
            composable("history") { HistoryScreen(onBack = { nav.popBackStack() }) }
        }
    }
}

@Composable
fun HomeScreen(onPlan: (String) -> Unit, onHistory: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("Apnea Trainer") }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Antrenman Seç", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(modifier = Modifier.weight(1f), onClick = { onPlan("co2") }) { Text("CO₂ Tablosu") }
                Button(modifier = Modifier.weight(1f), onClick = { onPlan("o2") }) { Text("O₂ Tablosu") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(modifier = Modifier.weight(1f), onClick = { onPlan("dynamic") }) { Text("Dinamik Yüzme") }
                Button(modifier = Modifier.weight(1f), onClick = { onPlan("fimm") }) { Text("Free Immersion") }
            }
            Button(onClick = { onPlan("hunt") }) { Text("Av Simülasyonu 5–6 m") }
            OutlinedButton(onClick = onHistory) { Text("Geçmiş") }
            Spacer(Modifier.weight(1f))
            Text("⚠️ Asla yalnız antrenman yapma. Hiperventilasyondan kaçın.")
        }
    }
}
