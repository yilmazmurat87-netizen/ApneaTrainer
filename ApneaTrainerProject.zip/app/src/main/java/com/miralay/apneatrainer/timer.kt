package com.miralay.apneatrainer

import android.content.Context
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

class SessionTimer(private val context: Context) {
    private var job: Job? = null
    private val _state = MutableStateFlow(TimerState())
    val state: StateFlow<TimerState> = _state

    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null

    fun initTts() {
        if (tts != null) return
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("tr", "TR")
            }
        }
    }

    fun speak(s: String) { tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, System.currentTimeMillis().toString()) }

    fun start(plan: Plan, onFinish: (() -> Unit)? = null) {
        if (job?.isActive == true) return
        acquireWakeLock()
        initTts()
        job = CoroutineScope(Dispatchers.Default).launch {
            var totalSeconds = 0
            val allSteps = mutableListOf<Step>()
            repeat(plan.rounds) { allSteps += plan.steps }

            for ((index, step) in allSteps.withIndex()) {
                _state.emit(TimerState(currentIndex = index, step = step, remaining = step.seconds, totalSeconds = totalSeconds, running = true, totalSteps = allSteps.size))
                speak(step.label)
                for (sec in step.seconds downTo 1) {
                    delay(1000)
                    totalSeconds += 1
                    val remaining = sec - 1
                    val announce = remaining in setOf(30, 20, 10, 5, 3, 2, 1)
                    if (announce) speak(remaining.toString())
                    _state.emit(_state.value.copy(remaining = remaining, totalSeconds = totalSeconds))
                    if (!isActive) return@launch
                }
            }
            _state.emit(_state.value.copy(running = false))
            speak("Bitti")
            releaseWakeLock()
            onFinish?.invoke()
        }
    }

    fun pause() { job?.cancel(); _state.value = _state.value.copy(running = false) }

    fun stop() { job?.cancel(); releaseWakeLock(); _state.value = TimerState() }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ApneaTrainer:Timer").apply { acquire(60*60*1000L) }
    }

    private fun releaseWakeLock() { wakeLock?.takeIf { it.isHeld }?.release() }
}

data class TimerState(
    val currentIndex: Int = -1,
    val step: Step? = null,
    val remaining: Int = 0,
    val totalSeconds: Int = 0,
    val running: Boolean = false,
    val totalSteps: Int = 0,
)
